from django.apps import AppConfig


class PrSearchAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pr_search_app'
